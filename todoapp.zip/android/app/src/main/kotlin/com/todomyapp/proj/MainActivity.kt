package com.todomyapp.proj

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
